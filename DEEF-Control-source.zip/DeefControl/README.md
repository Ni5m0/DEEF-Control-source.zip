# DEEF Control

App OBD2 originale (Kotlin + Jetpack Compose) con quadranti personalizzabili sul telefono
e una schermata per Android Auto (Car App Library). **Codice scritto ma non ancora compilato né provato:**
aspettati qualche errore da correggere al primo build.

## Cosa fa
- Connessione Bluetooth a un adattatore ELM327 già associato al telefono.
- PID standard (giri, velocità, temp. liquido, aspirazione, turbo, carico, farfalla, olio) e **PID personalizzati**
  (comando + formula con A,B,C,D, min/max/soglia di allarme) dalle Impostazioni.
- 3 temi originali (Cockpit, Racing, Ice) e slider per la grandezza dei quadranti sul telefono.
- Impostazioni per ogni quadro: PID, etichetta, unità, soglie gialla/rossa, numeri interi, conversione unità (°C/°F, bar/psi, km/h/mph, formula), colore, lancetta ad alta visibilità, min/max, scala, picco.
- Aspetto: 6 temi originali, 5 caratteri (compreso 7 segmenti), sfondi (nero, carbonio, sfumato) con scurisci/sfoca, opacità, indicatore centrale più grande, 1-3 quadri per pagina, titoli delle pagine.
- Quadranti con cornice metallica, scala con tacche, zona rossa e indicatore a punta (disegno originale).
- 4 pagine da 3 quadranti, configurabili dalle Impostazioni; stesse pagine su telefono e Android Auto.
- Android Auto: griglia con i 3 quadranti della pagina; il pulsante in alto passa alla pagina successiva
  (con la rotella dell'MMI si porta il fuoco sul pulsante e si preme; la sola rotazione non è intercettabile).
- Importazione: PID di Torque da CSV (Name, ShortName, ModeAndPID, Equation, Min, Max, Units, Header) e layout da
  `dashboards.pb` di AA Torque (solo PID standard modo 01). I temi/grafiche di Torque non sono importabili.

## Come compilare dal telefono (senza PC)
1. Crea un repository su GitHub e carica tutti i file di questa cartella (anche `.github/`).
2. Scheda **Actions** → "Build APK" → Run workflow.
3. A fine build scarica l'artefatto `DEEF-Control-debug` (APK di debug già firmato).

## Test su Android Auto
Installa l'APK, attiva le opzioni sviluppatore di Android Auto e "Origini sconosciute".

## Da verificare / fare prima del Play Store
- Categoria in `AndroidManifest.xml` (ora `IOT`): controlla nella documentazione attuale della Car App Library
  quale categoria Google accetta per un'app OBD. Se non ce n'è una adatta, l'app non potrà passare la revisione per Android Auto.
- `HostValidator.ALLOW_ALL_HOSTS_VALIDATOR` va sostituito con la lista di host consentiti.
- `targetSdk` secondo i requisiti attuali del Play Store; account sviluppatore, informativa privacy, Data safety.
- Dimensione/frequenza delle immagini per Android Auto (`bmpSize`, aggiornamento 1 s): regolare sul display reale.
- La lettura OBD gira solo finché il processo è attivo; per un uso affidabile serve un servizio in primo piano.
- Risposte multi-frame (alcuni PID modo 22) non sono ancora gestite.
- Niente loghi, nomi o grafiche di terzi (Audi, Nissan, Gran Turismo...): tieni i temi originali.

## Novità v4
- Nella Dash, tocca un quadrante per modificarlo (tipo di strumento, PID, etichetta, soglie, decimali, dimensione...).
- Tipi di strumento: lancetta, cursore, barre, digitale, grafico.
- Connessione OBD più robusta (3 modi di aprire il Bluetooth, attesa della ricerca del protocollo) e stato mostrato anche su Android Auto.
- Android Auto: layout "Pannello grande" (immagine larga con i quadranti) oppure "Griglia"; quadranti semplificati per leggersi meglio.
- PID dell'Audi S1 (Simos 18.1): Oil Pressure Simos e Oil Temp Simos (servizio 22, header 7E0).
