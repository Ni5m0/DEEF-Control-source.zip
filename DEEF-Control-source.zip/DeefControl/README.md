# DEEF Control

App OBD2 originale (Kotlin + Jetpack Compose) con quadranti personalizzabili sul telefono
e una schermata per Android Auto (Car App Library). **Codice scritto ma non ancora compilato né provato:**
aspettati qualche errore da correggere al primo build.

## Cosa fa
- Connessione Bluetooth a un adattatore ELM327 già associato al telefono.
- PID standard (giri, velocità, temp. liquido, aspirazione, turbo, carico, farfalla, olio) e **PID personalizzati**
  (comando + formula con A,B,C,D, min/max/soglia di allarme) dalle Impostazioni.
- 3 temi originali (Cockpit, Racing, Ice) e slider per la grandezza dei quadranti sul telefono.
- Android Auto: griglia con 3 quadranti grandi per pagina (immagini disegnate dallo stesso codice del telefono).

## Come compilare dal telefono (senza PC)
1. Crea un repository su GitHub e carica tutti i file di questa cartella (anche `.github/`).
2. Scheda **Actions** → "Build APK" → Run workflow.
3. A fine build scarica l'artefatto `DEEF-Control-debug` (APK di debug già firmato).

## Test su Android Auto
Installa l'APK, attiva le opzioni sviluppatore di Android Auto e "Origini sconosciute".

## Da verificare / fare prima del Play Store
- Categoria in `AndroidManifest.xml` (ora `IOT`): controlla nella documentazione attuale della Car App Library
  quale categoria Google accetta per un'app OBD. Se non ce n'è una adatta, l'app non potrà passare la revisione per Android Auto.
- `HostValidator.ALLOW_ALL_HOSTS_VALIDATOR` va sostituito con la lista di host consentiti.
- `targetSdk` secondo i requisiti attuali del Play Store; account sviluppatore, informativa privacy, Data safety.
- Dimensione/frequenza delle immagini per Android Auto (`bmpSize`, aggiornamento 1 s): regolare sul display reale.
- La lettura OBD gira solo finché il processo è attivo; per un uso affidabile serve un servizio in primo piano.
- Risposte multi-frame (alcuni PID modo 22) non sono ancora gestite.
- Niente loghi, nomi o grafiche di terzi (Audi, Nissan, Gran Turismo...): tieni i temi originali.
