package com.deef.control

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.deef.control.obd.BuiltInPids
import com.deef.control.obd.Formula
import com.deef.control.obd.ObdRepository
import com.deef.control.obd.Pid
import com.deef.control.ui.GaugeCompose
import com.deef.control.ui.GaugeTheme

class MainActivity : ComponentActivity() {
    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.init(this)
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
        }
        ObdRepository.ensureStarted(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) { App() }
            }
        }
    }
}

@Composable
fun App() {
    var screen by remember { mutableIntStateOf(0) }
    val status by ObdRepository.status.collectAsState()
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text("DEEF Control", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Row {
                TextButton(onClick = { screen = 0 }) { Text("Dash") }
                TextButton(onClick = { screen = 1 }) { Text("Impostazioni") }
            }
        }
        Text(status, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 12.dp))
        if (screen == 0) Dashboard() else SettingsScreen()
    }
}

@Composable
fun Dashboard() {
    val values by ObdRepository.values.collectAsState()
    val pids = Settings.activePids()
    val theme = Settings.theme
    val scale = Settings.scale
    LazyVerticalGrid(
        columns = GridCells.Adaptive((180 * scale).dp),
        contentPadding = PaddingValues(8.dp),
    ) {
        items(pids) { pid ->
            Column(Modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(pid.name, fontSize = 13.sp)
                GaugeCompose(pid, values[pid.id], theme, Modifier.fillMaxWidth().aspectRatio(1f))
            }
        }
    }
}

@SuppressLint("MissingPermission")
fun bondedDevices(ctx: Context): List<Pair<String, String>> = try {
    val a = (ctx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
    a?.bondedDevices?.map { (it.name ?: "?") to it.address } ?: emptyList()
} catch (e: SecurityException) {
    emptyList()
}

@Composable
fun SettingsScreen() {
    val ctx = LocalContext.current
    var theme by remember { mutableStateOf(Settings.theme) }
    var scale by remember { mutableFloatStateOf(Settings.scale) }
    var addr by remember { mutableStateOf(Settings.deviceAddress) }
    val selected = remember { mutableStateListOf<String>().apply { addAll(Settings.selectedIds) } }
    var custom by remember { mutableStateOf(Settings.customPids) }
    val devices = remember { bondedDevices(ctx) }

    var fName by remember { mutableStateOf("") }
    var fShort by remember { mutableStateOf("") }
    var fUnit by remember { mutableStateOf("") }
    var fCmd by remember { mutableStateOf("") }
    var fFormula by remember { mutableStateOf("A") }
    var fMin by remember { mutableStateOf("0") }
    var fMax by remember { mutableStateOf("100") }
    var fWarn by remember { mutableStateOf("90") }
    var formError by remember { mutableStateOf("") }

    val all = BuiltInPids.all + custom

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        item { Text("Adattatore OBD (Bluetooth già associato)", fontWeight = FontWeight.Bold) }
        if (devices.isEmpty()) item { Text("Nessun dispositivo associato (o permesso Bluetooth negato).", fontSize = 12.sp) }
        items(devices) { d ->
            TextButton(onClick = {
                Settings.deviceAddress = d.second
                addr = d.second
                ObdRepository.start(ctx)
            }) { Text(d.first + if (d.second == addr) "  ✓" else "") }
        }

        item { Text("Tema", fontWeight = FontWeight.Bold) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GaugeTheme.entries.forEach { t ->
                    FilterChip(
                        selected = theme == t,
                        onClick = { theme = t; Settings.theme = t },
                        label = { Text(t.label) },
                    )
                }
            }
        }

        item { Text("Grandezza quadranti sul telefono", fontWeight = FontWeight.Bold) }
        item {
            Slider(
                value = scale,
                onValueChange = { scale = it },
                onValueChangeFinished = { Settings.scale = scale },
                valueRange = 0.6f..2.2f,
            )
        }

        item { Text("Parametri mostrati (telefono e Android Auto)", fontWeight = FontWeight.Bold) }
        items(all) { pid ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(
                    checked = pid.id in selected,
                    onCheckedChange = { c ->
                        if (c) selected.add(pid.id) else selected.remove(pid.id)
                        Settings.selectedIds = selected.toList()
                    },
                )
                Text("${pid.name} (${pid.unit})", modifier = Modifier.weight(1f))
                if (pid.custom) {
                    TextButton(onClick = {
                        custom = custom.filter { it.id != pid.id }
                        Settings.customPids = custom
                        selected.remove(pid.id)
                        Settings.selectedIds = selected.toList()
                    }) { Text("Elimina") }
                }
            }
        }

        item { Text("Nuovo PID personalizzato", fontWeight = FontWeight.Bold) }
        item { OutlinedTextField(fName, { fName = it }, label = { Text("Nome") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(fShort, { fShort = it }, label = { Text("Nome corto (es. EGT)") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(fUnit, { fUnit = it }, label = { Text("Unità (es. °C, bar)") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(fCmd, { fCmd = it }, label = { Text("Comando (es. 010C o 221234)") }, modifier = Modifier.fillMaxWidth()) }
        item { OutlinedTextField(fFormula, { fFormula = it }, label = { Text("Formula con A,B,C,D (es. (A*256+B)/4)") }, modifier = Modifier.fillMaxWidth()) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(fMin, { fMin = it }, label = { Text("Min") }, modifier = Modifier.weight(1f))
                OutlinedTextField(fMax, { fMax = it }, label = { Text("Max") }, modifier = Modifier.weight(1f))
                OutlinedTextField(fWarn, { fWarn = it }, label = { Text("Allarme") }, modifier = Modifier.weight(1f))
            }
        }
        item {
            Column {
                if (formError.isNotEmpty()) Text(formError, color = Color(0xFFFF5252), fontSize = 12.sp)
                Button(onClick = {
                    val mn = fMin.replace(',', '.').toDoubleOrNull()
                    val mx = fMax.replace(',', '.').toDoubleOrNull()
                    val wn = fWarn.replace(',', '.').toDoubleOrNull()
                    val cmdOk = fCmd.length >= 4 && fCmd.all { it.isDigit() || it.uppercaseChar() in 'A'..'F' }
                    val fOk = Formula.eval(fFormula, mapOf('A' to 1.0, 'B' to 1.0, 'C' to 1.0, 'D' to 1.0)) != null
                    formError = when {
                        fName.isBlank() -> "Inserisci un nome"
                        !cmdOk -> "Comando non valido (solo cifre esadecimali, almeno 4)"
                        !fOk -> "Formula non valida"
                        mn == null || mx == null || wn == null || mx <= mn -> "Min/Max/Allarme non validi"
                        else -> ""
                    }
                    if (formError.isEmpty()) {
                        val pid = Pid(
                            "C_" + System.currentTimeMillis(), fName.trim(),
                            fShort.ifBlank { fName }.trim().take(8), fUnit.trim(),
                            fCmd.uppercase(), fFormula.trim(), mn!!, mx!!, wn!!, true,
                        )
                        custom = custom + pid
                        Settings.customPids = custom
                        fName = ""; fShort = ""; fUnit = ""; fCmd = ""
                    }
                }) { Text("Aggiungi PID") }
            }
        }
    }
}
