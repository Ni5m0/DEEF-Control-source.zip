package com.deef.control.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

/** Connessione Bluetooth classica (SPP) a un adattatore ELM327. */
class ElmConnection(private val device: BluetoothDevice) {
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    @SuppressLint("MissingPermission")
    fun open() {
        val s = device.createRfcommSocketToServiceRecord(
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        )
        s.connect()
        socket = s
        input = s.inputStream
        output = s.outputStream
        for (c in listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0")) send(c, 2500)
    }

    /** Invia un comando e legge fino al prompt '>'. */
    fun send(cmd: String, timeoutMs: Long = 1500): String {
        val o = output ?: throw IOException("non connesso")
        val i = input ?: throw IOException("non connesso")
        o.write((cmd + "\r").toByteArray())
        o.flush()
        val sb = StringBuilder()
        val end = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < end) {
            if (i.available() > 0) {
                val c = i.read()
                if (c < 0) throw IOException("connessione chiusa")
                val ch = c.toChar()
                if (ch == '>') break
                sb.append(ch)
            } else {
                Thread.sleep(5)
            }
        }
        return sb.toString().replace('\r', ' ').replace('\n', ' ').trim()
    }

    fun close() {
        runCatching { socket?.close() }
    }

    companion object {
        /** Estrae i byte A,B,C,D dalla risposta e applica la formula del PID. */
        fun decode(pid: Pid, resp: String): Double? {
            val cmd = pid.command.uppercase()
            if (cmd.length < 4) return null
            val mode = cmd.substring(0, 2).toIntOrNull(16) ?: return null
            val prefix = String.format("%02X", mode + 0x40) + cmd.substring(2)
            val clean = resp.replace(" ", "").uppercase()
            val idx = clean.indexOf(prefix)
            if (idx < 0) return null
            val data = clean.substring(idx + prefix.length)
            val bytes = data.chunked(2).take(4).mapNotNull { it.toIntOrNull(16) }
            if (bytes.isEmpty()) return null
            val vars = mutableMapOf('A' to 0.0, 'B' to 0.0, 'C' to 0.0, 'D' to 0.0)
            bytes.forEachIndexed { n, b -> vars['A' + n] = b.toDouble() }
            return Formula.eval(pid.formula, vars)
        }
    }
}
