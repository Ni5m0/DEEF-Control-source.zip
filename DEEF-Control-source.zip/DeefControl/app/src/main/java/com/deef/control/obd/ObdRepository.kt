package com.deef.control.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.content.Context
import com.deef.control.Settings
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Unico punto di lettura OBD, condiviso tra schermata telefono e schermata Android Auto. */
object ObdRepository {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null

    val values = MutableStateFlow<Map<String, Double>>(emptyMap())
    val status = MutableStateFlow("Non connesso")

    /** Minimo e massimo raggiunti da ogni PID (valori grezzi, prima della conversione). */
    val minMax = MutableStateFlow<Map<String, Pair<Double, Double>>>(emptyMap())

    /** Ultimi valori di ogni PID (grezzi), per lo strumento a grafico. */
    val history = MutableStateFlow<Map<String, List<Double>>>(emptyMap())

    fun resetStats() {
        minMax.value = emptyMap()
        history.value = emptyMap()
    }

    fun ensureStarted(ctx: Context) {
        if (job?.isActive != true) start(ctx)
    }

    fun stop() {
        job?.cancel()
        job = null
        status.value = "Non connesso"
    }

    @SuppressLint("MissingPermission")
    fun start(ctx: Context) {
        stop()
        val app = ctx.applicationContext
        Settings.init(app)
        val addr = Settings.deviceAddress
        if (addr.isBlank()) {
            status.value = "Scegli un adattatore nelle Impostazioni"
            return
        }
        job = scope.launch {
            while (isActive) {
                var conn: ElmConnection? = null
                try {
                    val adapter = (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                    conn = ElmConnection(adapter, adapter.getRemoteDevice(addr))
                    status.value = "Connessione..."
                    conn.open()
                    status.value = "Connesso"
                    var hdr = ""
                    while (isActive) {
                        val pids = Settings.activePids()
                        if (pids.isEmpty()) {
                            delay(500)
                            continue
                        }
                        var got = 0
                        for (pid in pids) {
                            if (pid.header != hdr) {
                                conn.send("ATSH" + pid.header.ifBlank { "7DF" })
                                hdr = pid.header
                            }
                            val v = ElmConnection.decode(pid, conn.send(pid.command))
                            if (v != null) {
                                got++
                                values.value = values.value + (pid.id to v)
                                history.value = history.value + (pid.id to ((history.value[pid.id] ?: emptyList()) + v).takeLast(150))
                                val old = minMax.value[pid.id]
                                val nv = if (old == null) (v to v) else (minOf(old.first, v) to maxOf(old.second, v))
                                minMax.value = minMax.value + (pid.id to nv)
                            }
                        }
                        status.value = if (got > 0) "Connesso" else "Connesso, ma nessun dato dai PID (quadro acceso?)"
                    }
                } catch (e: Exception) {
                    status.value = "Errore: ${e.message ?: "sconosciuto"}. Riprovo..."
                } finally {
                    conn?.close()
                }
                delay(3000)
            }
        }
    }
}
