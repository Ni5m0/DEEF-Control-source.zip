package com.deef.control

import android.content.Context
import android.content.SharedPreferences
import com.deef.control.obd.BuiltInPids
import com.deef.control.obd.Pid
import com.deef.control.ui.GaugeTheme
import org.json.JSONArray
import org.json.JSONObject

object Settings {
    private lateinit var p: SharedPreferences

    fun init(c: Context) {
        if (!::p.isInitialized) {
            p = c.applicationContext.getSharedPreferences("deef", Context.MODE_PRIVATE)
        }
    }

    var deviceAddress: String
        get() = p.getString("dev", "") ?: ""
        set(v) { p.edit().putString("dev", v).apply() }

    var theme: GaugeTheme
        get() = runCatching { GaugeTheme.valueOf(p.getString("theme", "COCKPIT") ?: "COCKPIT") }
            .getOrDefault(GaugeTheme.COCKPIT)
        set(v) { p.edit().putString("theme", v.name).apply() }

    /** Fattore di grandezza dei quadranti sul telefono (0.6 - 2.2). */
    var scale: Float
        get() = p.getFloat("scale", 1f)
        set(v) { p.edit().putFloat("scale", v).apply() }

    var selectedIds: List<String>
        get() = (p.getString("sel", "RPM,BOOST,COOLANT") ?: "").split(",").filter { it.isNotBlank() }
        set(v) { p.edit().putString("sel", v.joinToString(",")).apply() }

    var customPids: List<Pid>
        get() {
            val arr = JSONArray(p.getString("custom", "[]") ?: "[]")
            return (0 until arr.length()).map { n ->
                val o = arr.getJSONObject(n)
                Pid(
                    o.getString("id"), o.getString("name"), o.getString("short"), o.getString("unit"),
                    o.getString("cmd"), o.getString("formula"),
                    o.getDouble("min"), o.getDouble("max"), o.getDouble("warn"), true,
                )
            }
        }
        set(v) {
            val arr = JSONArray()
            v.forEach {
                arr.put(JSONObject().apply {
                    put("id", it.id); put("name", it.name); put("short", it.shortName)
                    put("unit", it.unit); put("cmd", it.command); put("formula", it.formula)
                    put("min", it.min); put("max", it.max); put("warn", it.warn)
                })
            }
            p.edit().putString("custom", arr.toString()).apply()
        }

    fun allPids(): List<Pid> = BuiltInPids.all + customPids

    fun activePids(): List<Pid> {
        val all = allPids()
        return selectedIds.mapNotNull { id -> all.find { it.id == id } }
    }
}
