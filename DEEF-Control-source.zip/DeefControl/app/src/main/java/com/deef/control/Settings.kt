package com.deef.control

import android.content.Context
import android.content.SharedPreferences
import com.deef.control.obd.BuiltInPids
import com.deef.control.obd.Pid
import com.deef.control.ui.BgStyle
import com.deef.control.ui.GaugeFont
import com.deef.control.ui.GaugeResolver
import com.deef.control.ui.GaugeSpec
import com.deef.control.ui.GaugeTheme
import com.deef.control.ui.RenderStyle
import com.deef.control.ui.SlotConfig
import org.json.JSONArray
import org.json.JSONObject

object Settings {
    const val PAGES = 4
    const val SLOTS = 3
    private const val DEFAULT_SLOTS = "RPM,BOOST,COOLANT,SPEED,LOAD,THROTTLE,IAT,OILTEMP,-,-,-,-"

    private lateinit var p: SharedPreferences

    fun init(c: Context) {
        if (!::p.isInitialized) {
            p = c.applicationContext.getSharedPreferences("deef", Context.MODE_PRIVATE)
        }
    }

    // ---------- adattatore ----------
    var deviceAddress: String
        get() = p.getString("dev", "") ?: ""
        set(v) { p.edit().putString("dev", v).apply() }

    // ---------- aspetto ----------
    var theme: GaugeTheme
        get() = runCatching { GaugeTheme.valueOf(p.getString("theme", "COCKPIT") ?: "COCKPIT") }
            .getOrDefault(GaugeTheme.COCKPIT)
        set(v) { p.edit().putString("theme", v.name).apply() }

    var font: GaugeFont
        get() = runCatching { GaugeFont.valueOf(p.getString("font", "SISTEMA") ?: "SISTEMA") }
            .getOrDefault(GaugeFont.SISTEMA)
        set(v) { p.edit().putString("font", v.name).apply() }

    var background: BgStyle
        get() = runCatching { BgStyle.valueOf(p.getString("bg", "CARBONIO") ?: "CARBONIO") }
            .getOrDefault(BgStyle.CARBONIO)
        set(v) { p.edit().putString("bg", v.name).apply() }

    /** Scurisci lo sfondo, 0-100. */
    var darken: Int
        get() = p.getInt("darken", 0).coerceIn(0, 100)
        set(v) { p.edit().putInt("darken", v).apply() }

    /** Sfocatura dello sfondo, 0-20 (solo Android 12 o successivo). */
    var blur: Int
        get() = p.getInt("blur", 0).coerceIn(0, 20)
        set(v) { p.edit().putInt("blur", v).apply() }

    /** Opacità degli indicatori, 0-100. */
    var opacity: Int
        get() = p.getInt("opacity", 100).coerceIn(0, 100)
        set(v) { p.edit().putInt("opacity", v).apply() }

    var bigCenter: Boolean
        get() = p.getBoolean("bigcenter", true)
        set(v) { p.edit().putBoolean("bigcenter", v).apply() }

    var minMaxBelow: Boolean
        get() = p.getBoolean("mmbelow", false)
        set(v) { p.edit().putBoolean("mmbelow", v).apply() }

    /** Numero di quadri mostrati per pagina (1-3). */
    var perPage: Int
        get() = p.getInt("perpage", 3).coerceIn(1, SLOTS)
        set(v) { p.edit().putInt("perpage", v).apply() }

    /** Grandezza dei quadranti sul telefono in verticale (0.5 - 1.0 della larghezza). */
    var scale: Float
        get() = p.getFloat("scale", 1f).coerceIn(0.5f, 1f)
        set(v) { p.edit().putFloat("scale", v).apply() }

    val titles: List<String>
        get() {
            val raw = (p.getString("titles", "") ?: "").split("|")
            return List(PAGES) { i -> raw.getOrNull(i)?.takeIf { it.isNotBlank() } ?: "Pagina ${i + 1}" }
        }

    fun setTitle(i: Int, t: String) {
        val l = (0 until PAGES).map { j -> if (j == i) t.replace('|', ' ') else titles[j] }
        p.edit().putString("titles", l.joinToString("|")).apply()
    }

    fun renderStyle(compact: Boolean = false): RenderStyle =
        RenderStyle(theme, font, opacity / 100f, minMaxBelow, compact)

    /** Layout della schermata Android Auto: "GRID" (griglia) oppure "PANE" (pannello con immagine grande). */
    var aaLayout: String
        get() = p.getString("aalayout", "PANE") ?: "PANE"
        set(v) { p.edit().putString("aalayout", v).apply() }

    // ---------- quadri (4 pagine x 3 posizioni) ----------
    var slotConfigs: List<SlotConfig>
        get() {
            val s = p.getString("slotcfg", null)
            if (s == null) {
                val ids = (p.getString("slots", DEFAULT_SLOTS) ?: DEFAULT_SLOTS).split(",")
                return List(PAGES * SLOTS) { SlotConfig(pidId = ids.getOrElse(it) { "-" }) }
            }
            val arr = JSONArray(s)
            return List(PAGES * SLOTS) { i ->
                if (i >= arr.length()) SlotConfig() else slotFromJson(arr.getJSONObject(i))
            }
        }
        set(v) {
            val arr = JSONArray()
            v.forEach { arr.put(slotToJson(it)) }
            p.edit().putString("slotcfg", arr.toString()).apply()
        }

    fun setSlot(i: Int, c: SlotConfig) {
        val l = slotConfigs.toMutableList()
        l[i] = c
        slotConfigs = l
    }

    private fun slotToJson(c: SlotConfig) = JSONObject().apply {
        put("enabled", c.enabled); put("pid", c.pidId); put("showLabel", c.showLabel)
        put("label", c.label); put("unit", c.unit)
        c.yellow?.let { put("yellow", it) }
        c.red?.let { put("red", it) }
        c.low?.let { put("low", it) }
        put("decimals", c.decimals); put("type", c.type); put("size", c.size.toDouble())
        put("int", c.intNumbers); put("conv", c.conv); put("convF", c.convFormula)
        put("color", c.color); put("hiVis", c.hiVis)
        c.min?.let { put("min", it) }
        c.max?.let { put("max", it) }
        put("showScale", c.showScale); put("showMinMax", c.showMinMax); put("showPeak", c.showPeak)
    }

    private fun slotFromJson(o: JSONObject) = SlotConfig(
        enabled = o.optBoolean("enabled", true),
        pidId = o.optString("pid", "-"),
        showLabel = o.optBoolean("showLabel", true),
        label = o.optString("label", ""),
        unit = o.optString("unit", ""),
        yellow = if (o.has("yellow")) o.getDouble("yellow") else null,
        red = if (o.has("red")) o.getDouble("red") else null,
        low = if (o.has("low")) o.getDouble("low") else null,
        decimals = o.optInt("decimals", -1),
        type = o.optString("type", "DIAL"),
        size = o.optDouble("size", 1.0).toFloat(),
        intNumbers = o.optBoolean("int", false),
        conv = o.optString("conv", "NONE"),
        convFormula = o.optString("convF", "A"),
        color = o.optLong("color", 0L),
        hiVis = o.optBoolean("hiVis", false),
        min = if (o.has("min")) o.getDouble("min") else null,
        max = if (o.has("max")) o.getDouble("max") else null,
        showScale = o.optBoolean("showScale", true),
        showMinMax = o.optBoolean("showMinMax", false),
        showPeak = o.optBoolean("showPeak", false),
    )

    // ---------- PID ----------
    var customPids: List<Pid>
        get() {
            val arr = JSONArray(p.getString("custom", "[]") ?: "[]")
            return (0 until arr.length()).map { n ->
                val o = arr.getJSONObject(n)
                Pid(
                    o.getString("id"), o.getString("name"), o.getString("short"), o.getString("unit"),
                    o.getString("cmd"), o.getString("formula"),
                    o.getDouble("min"), o.getDouble("max"), o.getDouble("warn"), true,
                    o.optString("header", ""),
                )
            }
        }
        set(v) {
            val arr = JSONArray()
            v.forEach {
                arr.put(JSONObject().apply {
                    put("id", it.id); put("name", it.name); put("short", it.shortName)
                    put("unit", it.unit); put("cmd", it.command); put("formula", it.formula)
                    put("min", it.min); put("max", it.max); put("warn", it.warn)
                    put("header", it.header)
                })
            }
            p.edit().putString("custom", arr.toString()).apply()
        }

    fun allPids(): List<Pid> = BuiltInPids.all + customPids

    /** Quadri visibili di una pagina (solo posizioni abilitate, entro il numero di quadri per pagina). */
    fun pageGauges(page: Int): List<GaugeSpec> {
        val all = allPids()
        val cfgs = slotConfigs
        return (0 until perPage).mapNotNull { s ->
            val c = cfgs[page * SLOTS + s]
            if (!c.enabled) null else all.find { it.id == c.pidId }?.let { GaugeResolver.resolve(c, it, page * SLOTS + s) }
        }
    }

    /** Tutti i PID usati nelle pagine (quelli da leggere dall'adattatore). */
    fun activePids(): List<Pid> {
        val all = allPids()
        val cfgs = slotConfigs
        val ids = ArrayList<String>()
        for (pg in 0 until PAGES) for (s in 0 until perPage) {
            val c = cfgs[pg * SLOTS + s]
            if (c.enabled && c.pidId != "-") ids.add(c.pidId)
        }
        return ids.distinct().mapNotNull { id -> all.find { it.id == id } }
    }
}
