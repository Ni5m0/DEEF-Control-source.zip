package com.deef.control.obd

/** Importa PID dal formato CSV di Torque (Name, ShortName, ModeAndPID, Equation, Min, Max, Units, Header). */
object TorqueImport {
    /** Ritorna i PID letti e il numero di righe scartate (formula non supportata o riga non valida). */
    fun parseCsv(text: String): Pair<List<Pid>, Int> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList<Pid>() to 0

        // colonne: da intestazione se presente, altrimenti ordine standard di Torque
        var idx = mapOf("name" to 0, "short" to 1, "cmd" to 2, "eq" to 3, "min" to 4, "max" to 5, "unit" to 6, "hdr" to 7)
        var body = lines
        val first = splitCsv(lines[0]).map { it.lowercase().replace(" ", "") }
        if (first.contains("name") && first.any { it.contains("modeandpid") || it == "pid" }) {
            fun find(vararg keys: String) = first.indexOfFirst { h -> keys.any { h.contains(it) } }
            idx = mapOf(
                "name" to first.indexOf("name"),
                "short" to find("shortname"),
                "cmd" to find("modeandpid", "pid"),
                "eq" to find("equation"),
                "min" to find("minvalue"),
                "max" to find("maxvalue"),
                "unit" to find("unit"),
                "hdr" to find("header"),
            )
            body = lines.drop(1)
        }

        val out = ArrayList<Pid>()
        var skipped = 0
        for (line in body) {
            val c = splitCsv(line)
            fun col(k: String): String = idx[k]?.takeIf { it >= 0 }?.let { c.getOrNull(it) }?.trim() ?: ""
            val name = col("name")
            val cmd = col("cmd").replace(" ", "").replace("0x", "", ignoreCase = true).uppercase()
            val eq = col("eq")
            val cmdOk = cmd.length >= 4 && cmd.all { it.isDigit() || it in 'A'..'F' }
            val eqOk = eq.isNotEmpty() && Formula.eval(eq, ('A'..'H').associateWith { 1.0 }) != null
            if (name.isEmpty() || !cmdOk || !eqOk) { skipped++; continue }
            val mn = col("min").replace(',', '.').toDoubleOrNull() ?: 0.0
            var mx = col("max").replace(',', '.').toDoubleOrNull() ?: 100.0
            if (mx <= mn) mx = mn + 100.0
            val short = col("short").ifBlank { name }.take(8)
            val hdr = col("hdr").replace(" ", "").uppercase().takeIf { h -> h.isNotEmpty() && h.all { it.isDigit() || it in 'A'..'F' } } ?: ""
            out.add(
                Pid("T_" + cmd + "_" + name.hashCode(), name, short, col("unit"), cmd, eq, mn, mx, mn + (mx - mn) * 0.9, true, hdr)
            )
        }
        return out to skipped
    }

    private fun splitCsv(line: String): List<String> {
        val res = ArrayList<String>()
        val sb = StringBuilder()
        var q = false
        for (ch in line) {
            when {
                ch == '"' -> q = !q
                ch == ',' && !q -> { res.add(sb.toString()); sb.clear() }
                else -> sb.append(ch)
            }
        }
        res.add(sb.toString())
        return res
    }
}

/** Importa le pagine/quadranti da un file "dashboards.pb" esportato da AA Torque (lettura tollerante). */
object AaTorqueImport {
    class Gauge(val id: String, val label: String, val unit: String)

    private class F(val num: Int, val b: ByteArray?)

    fun parse(buf: ByteArray): List<List<Gauge>> {
        val pages = ArrayList<List<Gauge>>()
        walk(buf, pages, 0)
        return pages
    }

    /** Trasforma un quadrante in un PID. Supporta solo i PID standard modo 01 ("torque_0c" = 010C). */
    fun toPid(g: Gauge): Pid? {
        val code = g.id.removePrefix("torque_").substringBefore(',')
        if (code.length != 2 || !code.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) return null
        val cmd = "01" + code.uppercase()
        BuiltInPids.all.find { it.command == cmd }?.let { return it }
        val label = g.label.ifBlank { cmd }
        // formula segnaposto "A": da correggere dopo l'importazione
        return Pid("A_$cmd", label, label.take(8), g.unit, cmd, "A", 0.0, 100.0, 90.0, true)
    }

    private fun walk(buf: ByteArray, pages: MutableList<List<Gauge>>, depth: Int) {
        if (depth > 8) return
        val fs = fields(buf) ?: return
        val gauges = ArrayList<Gauge>()
        for (f in fs) {
            val b = f.b ?: continue
            val sub = fields(b)
            if (sub == null || sub.isEmpty()) continue
            val id = sub.firstOrNull { it.num == 1 && it.b != null }?.b?.let { String(it, Charsets.UTF_8) } ?: ""
            if (id.startsWith("torque_")) {
                gauges.add(Gauge(id, str(sub, 3), str(sub, 12)))
            } else {
                walk(b, pages, depth + 1)
            }
        }
        if (gauges.isNotEmpty()) pages.add(gauges)
    }

    private fun str(fs: List<F>, num: Int): String =
        fs.firstOrNull { it.num == num && it.b != null }?.b?.let { String(it, Charsets.UTF_8) } ?: ""

    /** Lettore minimale di protobuf: ritorna null se i byte non sono un messaggio valido. */
    private fun fields(buf: ByteArray): List<F>? {
        val out = ArrayList<F>()
        var i = 0
        fun varint(): Long? {
            var r = 0L
            var s = 0
            while (i < buf.size) {
                val x = buf[i++].toInt() and 0xFF
                r = r or ((x and 0x7F).toLong() shl s)
                if ((x and 0x80) == 0) return r
                s += 7
                if (s > 63) return null
            }
            return null
        }
        while (i < buf.size) {
            val tag = varint() ?: return null
            val num = (tag shr 3).toInt()
            val wire = (tag and 7L).toInt()
            if (num == 0) return null
            when (wire) {
                0 -> { varint() ?: return null; out.add(F(num, null)) }
                1 -> { if (i + 8 > buf.size) return null; i += 8; out.add(F(num, null)) }
                2 -> {
                    val len = (varint() ?: return null).toInt()
                    if (len < 0 || i + len > buf.size) return null
                    out.add(F(num, buf.copyOfRange(i, i + len)))
                    i += len
                }
                5 -> { if (i + 4 > buf.size) return null; i += 4; out.add(F(num, null)) }
                else -> return null
            }
        }
        return out
    }
}
