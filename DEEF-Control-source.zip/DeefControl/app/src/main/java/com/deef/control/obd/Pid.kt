package com.deef.control.obd

/** Un parametro da leggere: comando OBD + formula che usa i byte A, B, C, D della risposta. */
data class Pid(
    val id: String,
    val name: String,
    val shortName: String,
    val unit: String,
    val command: String,   // es. "010C" (modo 01) oppure "221234" (modo 22, personalizzato)
    val formula: String,   // es. "(A*256+B)/4"
    val min: Double,
    val max: Double,
    val warn: Double,      // oltre questo valore l'arco diventa rosso
    val custom: Boolean = false,
)

object BuiltInPids {
    val all = listOf(
        Pid("RPM", "Giri motore", "RPM", "rpm", "010C", "(A*256+B)/4", 0.0, 8000.0, 6500.0),
        Pid("SPEED", "Velocita", "KM/H", "km/h", "010D", "A", 0.0, 260.0, 250.0),
        Pid("COOLANT", "Temp. liquido", "H2O", "°C", "0105", "A-40", 40.0, 130.0, 110.0),
        Pid("IAT", "Temp. aspirazione", "IAT", "°C", "010F", "A-40", -20.0, 80.0, 60.0),
        Pid("BOOST", "Pressione turbo", "TURBO", "bar", "010B", "A/100-1.013", -1.0, 2.0, 1.8),
        Pid("LOAD", "Carico motore", "LOAD", "%", "0104", "A*100/255", 0.0, 100.0, 95.0),
        Pid("THROTTLE", "Farfalla", "THR", "%", "0111", "A*100/255", 0.0, 100.0, 101.0),
        Pid("OILTEMP", "Temp. olio", "OLIO", "°C", "015C", "A-40", 40.0, 150.0, 130.0),
    )
}
