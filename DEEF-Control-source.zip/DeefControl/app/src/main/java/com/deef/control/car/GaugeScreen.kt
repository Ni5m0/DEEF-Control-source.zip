package com.deef.control.car

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.deef.control.Settings
import com.deef.control.obd.ObdRepository
import com.deef.control.ui.GaugeRenderer
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Schermata Android Auto: pochi quadranti grandi per pagina (modello a griglia di Google). */
class GaugeScreen(ctx: CarContext) : Screen(ctx) {
    private var page = 0
    private val perPage = 3
    private val bmpSize = 320 // dimensione immagine: da regolare dopo i test sul display reale

    init {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    delay(1000) // Google limita la frequenza di aggiornamento dei modelli
                    invalidate()
                }
            }
        }
    }

    override fun onGetTemplate(): Template {
        val pids = Settings.activePids()
        val pages = ((pids.size + perPage - 1) / perPage).coerceAtLeast(1)
        if (page >= pages) page = 0
        val values = ObdRepository.values.value
        val theme = Settings.theme

        val list = ItemList.Builder()
        pids.drop(page * perPage).take(perPage).forEach { pid ->
            val v = values[pid.id]
            val bmp = Bitmap.createBitmap(bmpSize, bmpSize, Bitmap.Config.ARGB_8888)
            GaugeRenderer.draw(Canvas(bmp), bmpSize.toFloat(), bmpSize.toFloat(), pid, v, theme)
            list.addItem(
                GridItem.Builder()
                    .setTitle(pid.shortName)
                    .setText(GaugeRenderer.format(v, pid) + " " + pid.unit)
                    .setImage(CarIcon.Builder(IconCompat.createWithBitmap(bmp)).build(), GridItem.IMAGE_TYPE_LARGE)
                    .build()
            )
        }
        if (pids.isEmpty()) {
            list.setNoItemsMessage("Scegli i parametri nelle Impostazioni sul telefono")
        }

        val strip = ActionStrip.Builder()
        if (pages > 1) {
            strip.addAction(
                Action.Builder()
                    .setTitle("Pagina ${page + 1}/$pages")
                    .setOnClickListener { page = (page + 1) % pages; invalidate() }
                    .build()
            )
        }

        val tpl = GridTemplate.Builder()
            .setTitle("DEEF Control")
            .setHeaderAction(Action.APP_ICON)
            .setSingleList(list.build())
        // ActionStrip richiede almeno un'azione: lo aggiungo solo se ci sono più pagine
        if (pages > 1) tpl.setActionStrip(strip.build())
        return tpl.build()
    }
}
