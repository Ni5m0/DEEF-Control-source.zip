package com.deef.control.car

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.GridItem
import androidx.car.app.model.GridTemplate
import androidx.car.app.model.ItemList
import androidx.car.app.model.Pane
import androidx.car.app.model.PaneTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.deef.control.Settings
import com.deef.control.obd.ObdRepository
import com.deef.control.ui.GaugeRenderer
import com.deef.control.ui.GaugeSpec
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Schermata Android Auto. Due layout (Impostazioni → Android Auto):
 *  - PANE: un pannello con un'immagine grande che contiene i quadranti affiancati (più leggibile);
 *  - GRID: la griglia di Google, con quadranti piccoli.
 * Il pulsante in alto passa alla pagina successiva: con la rotella dell'MMI si porta il fuoco
 * sul pulsante e si preme. Non è possibile intercettare la sola rotazione della rotella.
 */
class GaugeScreen(ctx: CarContext) : Screen(ctx) {
    private var page = 0
    private val bmpSize = 360

    init {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                while (true) {
                    delay(1000) // Google limita la frequenza di aggiornamento dei modelli
                    invalidate()
                }
            }
        }
    }

    private fun draw(g: GaugeSpec, canvas: Canvas, w: Float, h: Float) {
        val raw = ObdRepository.values.value[g.pidId]
        val st = ObdRepository.minMax.value[g.pidId]
        val hist = ObdRepository.history.value[g.pidId]
        GaugeRenderer.draw(
            canvas, w, h, g,
            raw?.let { g.convert(it) },
            st?.let { g.convert(it.first) }, st?.let { g.convert(it.second) },
            hist?.map { g.convert(it) },
            Settings.renderStyle(compact = true),
        )
    }

    private fun valueText(g: GaugeSpec): String {
        val v = ObdRepository.values.value[g.pidId]?.let { g.convert(it) }
        return GaugeRenderer.format(v, g) + " " + g.unit
    }

    override fun onGetTemplate(): Template {
        val gauges = Settings.pageGauges(page)
        val status = ObdRepository.status.value
        val title = "DEEF · " + status.take(34)

        val next = Action.Builder()
            .setTitle(Settings.titles[page] + " >")
            .setOnClickListener { page = (page + 1) % Settings.PAGES; invalidate() }
            .build()
        val strip = ActionStrip.Builder().addAction(next).build()

        if (Settings.aaLayout == "PANE") {
            val pane = Pane.Builder()
            if (gauges.isEmpty()) {
                pane.addRow(Row.Builder().setTitle("Pagina vuota").addText("Configurala nelle Impostazioni sul telefono").build())
            } else {
                gauges.take(4).forEach { g ->
                    pane.addRow(Row.Builder().setTitle(g.label).addText(valueText(g)).build())
                }
                val n = gauges.size
                val bmp = Bitmap.createBitmap(bmpSize * n, bmpSize, Bitmap.Config.ARGB_8888)
                val c = Canvas(bmp)
                gauges.forEachIndexed { i, g ->
                    c.save()
                    c.translate((i * bmpSize).toFloat(), 0f)
                    draw(g, c, bmpSize.toFloat(), bmpSize.toFloat())
                    c.restore()
                }
                pane.setImage(CarIcon.Builder(IconCompat.createWithBitmap(bmp)).build())
            }
            return PaneTemplate.Builder(pane.build())
                .setTitle(title)
                .setHeaderAction(Action.APP_ICON)
                .setActionStrip(strip)
                .build()
        }

        val list = ItemList.Builder()
        gauges.forEach { g ->
            val bmp = Bitmap.createBitmap(bmpSize, bmpSize, Bitmap.Config.ARGB_8888)
            draw(g, Canvas(bmp), bmpSize.toFloat(), bmpSize.toFloat())
            list.addItem(
                GridItem.Builder()
                    .setTitle(g.label)
                    .setText(valueText(g))
                    .setImage(CarIcon.Builder(IconCompat.createWithBitmap(bmp)).build(), GridItem.IMAGE_TYPE_LARGE)
                    .build()
            )
        }
        if (gauges.isEmpty()) {
            list.setNoItemsMessage("Pagina vuota: configurala nelle Impostazioni sul telefono")
        }
        return GridTemplate.Builder()
            .setTitle(title)
            .setHeaderAction(Action.APP_ICON)
            .setSingleList(list.build())
            .setActionStrip(strip)
            .build()
    }
}
