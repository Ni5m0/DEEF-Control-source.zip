package com.deef.control.ui

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Temi originali (nomi e grafica non legati a marchi di terzi). Colori in ARGB. */
enum class GaugeTheme(val label: String, val bg: Long, val ring: Long, val arc: Long, val text: Long) {
    COCKPIT("Cockpit", 0xFF1E1E1E, 0xFFCFCFCF, 0xFFE0201C, 0xFFF2F2F2),
    RACING("Racing", 0xFF16191D, 0xFF8A94A0, 0xFFFFB000, 0xFFFFFFFF),
    ICE("Ice", 0xFF0B1722, 0xFF7FB8E0, 0xFF2EC4FF, 0xFFEAF6FF),
    RAME("Rame", 0xFF1A1411, 0xFFC98B5B, 0xFFE07B39, 0xFFF5E6DA),
    VERDE("Verde", 0xFF0C1710, 0xFF7FC48F, 0xFF3DDC84, 0xFFE8F8EC),
    MONO("Mono", 0xFF111111, 0xFF9E9E9E, 0xFFFFFFFF, 0xFFFFFFFF),
}

const val WARN_COLOR = 0xFFFF3B30
const val YELLOW_COLOR = 0xFFFFC107
const val LOW_COLOR = 0xFF2979FF

/** Sfondi disegnati da codice (nessuna immagine di terzi). */
object Backgrounds {
    private val tile: Bitmap by lazy {
        val b = Bitmap.createBitmap(12, 12, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        val p = Paint()
        for (i in 0 until 3) for (j in 0 until 3) {
            p.color = if ((i + j) % 2 == 0) 0xFF222222.toInt() else 0xFF0A0A0A.toInt()
            c.drawRect(i * 4f, j * 4f, (i + 1) * 4f, (j + 1) * 4f, p)
        }
        b
    }

    fun draw(c: Canvas, w: Float, h: Float, bg: BgStyle, darken: Float) {
        val p = Paint()
        when (bg) {
            BgStyle.NERO -> c.drawColor(android.graphics.Color.BLACK)
            BgStyle.CARBONIO -> {
                p.shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
                c.drawRect(0f, 0f, w, h, p)
            }
            BgStyle.SFUMATO -> {
                p.shader = LinearGradient(0f, 0f, 0f, h, 0xFF1B1F24.toInt(), 0xFF000000.toInt(), Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w, h, p)
            }
        }
        if (darken > 0f) {
            val q = Paint()
            q.color = android.graphics.Color.BLACK
            q.alpha = (darken.coerceIn(0f, 1f) * 255).toInt()
            c.drawRect(0f, 0f, w, h, q)
        }
    }
}

/**
 * Strumenti disegnati da codice: quadrante con lancetta/cursore, barre, digitale, grafico.
 * Un solo disegno usato sia sul telefono (Compose) sia per Android Auto.
 */
object GaugeRenderer {

    fun format(v: Double?, spec: GaugeSpec): String = when {
        v == null -> "--"
        spec.decimals >= 0 -> String.format("%." + spec.decimals + "f", v)
        abs(v) < 100 -> String.format("%.1f", v)
        else -> String.format("%.0f", v)
    }

    private fun withAlpha(c: Int, a: Float): Int =
        (c and 0x00FFFFFF) or ((a.coerceIn(0f, 1f) * 255).toInt() shl 24)

    /** Colore dell'indicatore: normale, giallo, oppure rosso se oltre l'allarme alto o sotto il basso. */
    private fun accentFor(spec: GaugeSpec, value: Double?, style: RenderStyle): Int {
        val base = if (spec.color != 0L) spec.color.toInt() else style.theme.arc.toInt()
        val red = spec.red
        val yellow = spec.yellow
        val low = spec.low
        return when {
            value != null && red != null && value >= red -> WARN_COLOR.toInt()
            value != null && low != null && value <= low -> WARN_COLOR.toInt()
            value != null && yellow != null && value >= yellow -> YELLOW_COLOR.toInt()
            else -> base
        }
    }

    fun draw(
        canvas: Canvas, w: Float, h: Float, spec: GaugeSpec,
        value: Double?, lo: Double?, hi: Double?, hist: List<Double>?, style: RenderStyle,
    ) {
        when (spec.type) {
            GaugeType.DIAL, GaugeType.ARC -> drawDial(canvas, w, h, spec, value, lo, hi, style)
            GaugeType.BAR -> drawBar(canvas, w, h, spec, value, hi, style)
            GaugeType.DIGITAL -> drawDigital(canvas, w, h, spec, value, lo, hi, style)
            GaugeType.GRAPH -> drawGraph(canvas, w, h, spec, value, hist, style)
        }
    }

    // ---------------------------------------------------------------- quadrante

    private fun drawDial(
        canvas: Canvas, w: Float, h: Float, spec: GaugeSpec,
        value: Double?, lo: Double?, hi: Double?, style: RenderStyle,
    ) {
        val theme = style.theme
        val compact = style.compact
        val size = min(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val r = size / 2f * 0.97f
        val start = 135f
        val span = 270f
        val range = spec.max - spec.min
        fun fr(v: Double): Float = ((v - spec.min) / range).coerceIn(0.0, 1.0).toFloat()
        val frac = if (value == null) 0f else fr(value)
        val red = spec.red
        val yellow = spec.yellow
        val low = spec.low
        val ind = withAlpha(accentFor(spec, value, style), style.opacity)
        val ring = theme.ring.toInt()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // cornice metallica
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            cx - r, cy - r, cx + r, cy + r,
            intArrayOf(
                ColorUtils.blendARGB(ring, 0xFFFFFFFF.toInt(), 0.6f),
                ColorUtils.blendARGB(ring, 0xFF000000.toInt(), 0.5f),
                ColorUtils.blendARGB(ring, 0xFFFFFFFF.toInt(), 0.5f),
                ColorUtils.blendARGB(ring, 0xFF000000.toInt(), 0.6f),
            ),
            null, Shader.TileMode.CLAMP,
        )
        canvas.drawCircle(cx, cy, r, p)
        p.shader = null
        p.color = 0xFF0A0A0A.toInt()
        canvas.drawCircle(cx, cy, r * 0.95f, p)

        // fondo del quadrante
        p.shader = RadialGradient(cx, cy, r * 0.93f, theme.bg.toInt(), 0xFF000000.toInt(), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 0.93f, p)
        p.shader = null

        // zone gialla, rossa (alta) e rossa (bassa)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.BUTT
        val zr = r * 0.885f
        val zrect = RectF(cx - zr, cy - zr, cx + zr, cy + zr)
        p.strokeWidth = r * 0.03f
        if (yellow != null) {
            val f0 = fr(yellow)
            val f1 = if (red != null) fr(red) else 1f
            if (f0 < f1) {
                p.color = YELLOW_COLOR.toInt()
                canvas.drawArc(zrect, start + span * f0, span * (f1 - f0), false, p)
            }
        }
        if (red != null) {
            val f0 = fr(red)
            if (f0 < 1f) {
                p.color = WARN_COLOR.toInt()
                canvas.drawArc(zrect, start + span * f0, span * (1f - f0), false, p)
            }
        }
        if (low != null) {
            val f1 = fr(low)
            if (f1 > 0f) {
                p.color = WARN_COLOR.toInt()
                canvas.drawArc(zrect, start, span * f1, false, p)
            }
        }

        // tacche
        p.color = theme.text.toInt()
        for (n in 0..30) {
            val major = n % 5 == 0
            val a = Math.toRadians((start + span * n / 30f).toDouble())
            val r1 = r * (if (major) 0.74f else 0.80f)
            val r2 = r * 0.86f
            p.strokeWidth = r * (if (major) 0.022f else 0.01f)
            canvas.drawLine(
                cx + (r1 * cos(a)).toFloat(), cy + (r1 * sin(a)).toFloat(),
                cx + (r2 * cos(a)).toFloat(), cy + (r2 * sin(a)).toFloat(), p,
            )
        }

        // arco del valore (più spesso nel tipo "cursore")
        val cursorType = spec.type == GaugeType.ARC
        if (value != null) {
            val vr = r * (if (cursorType) 0.76f else 0.70f)
            p.color = ind
            p.strokeWidth = r * (if (cursorType) 0.09f else 0.03f)
            canvas.drawArc(RectF(cx - vr, cy - vr, cx + vr, cy + vr), start, span * frac, false, p)
        }

        // numeri della scala
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = theme.text.toInt()
        tp.textAlign = Paint.Align.CENTER
        if (spec.showScale && !compact) {
            tp.textSize = r * 0.085f
            for (n in 0..6) {
                val a = Math.toRadians((start + span * n / 6f).toDouble())
                val lr = r * 0.62f
                val v = spec.min + range * n / 6
                val label = if (range > 20) String.format("%.0f", v) else String.format("%.1f", v)
                canvas.drawText(label, cx + (lr * cos(a)).toFloat(), cy + (lr * sin(a)).toFloat() + tp.textSize / 3f, tp)
            }
        }

        // picco (valore massimo raggiunto)
        if (spec.showPeak && hi != null) {
            val a = Math.toRadians((start + span * fr(hi)).toDouble())
            p.color = 0xFFFFFFFF.toInt()
            p.strokeWidth = r * 0.025f
            canvas.drawLine(
                cx + (r * 0.68f * cos(a)).toFloat(), cy + (r * 0.68f * sin(a)).toFloat(),
                cx + (r * 0.91f * cos(a)).toFloat(), cy + (r * 0.91f * sin(a)).toFloat(), p,
            )
        }

        // indicatore a punta (assente nel tipo "cursore")
        if (!cursorType) {
            val ang = Math.toRadians((start + span * frac).toDouble())
            val ca = cos(ang).toFloat()
            val sa = sin(ang).toFloat()
            val tipR = r * (if (spec.hiVis) 0.90f else 0.88f)
            val baseR = r * 0.58f
            val hw = r * (if (spec.hiVis) 0.075f else 0.04f)
            val path = Path()
            path.moveTo(cx + tipR * ca, cy + tipR * sa)
            path.lineTo(cx + baseR * ca - hw * sa, cy + baseR * sa + hw * ca)
            path.lineTo(cx + baseR * ca + hw * sa, cy + baseR * sa - hw * ca)
            path.close()
            p.style = Paint.Style.FILL
            p.color = ind
            canvas.drawPath(path, p)
        }

        // cerchio centrale
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 0.46f, 0xFF2C2C2C.toInt(), 0xFF080808.toInt(), Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, r * 0.46f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.018f
        p.color = 0xFFBDBDBD.toInt()
        canvas.drawCircle(cx, cy, r * 0.46f, p)

        // valore
        val text = format(value, spec)
        tp.alpha = 255
        tp.color = theme.text.toInt()
        if (style.font == GaugeFont.SETTE_SEG) {
            p.style = Paint.Style.FILL
            p.color = theme.text.toInt()
            drawSeven(canvas, text, cx, cy - r * 0.02f, r * (if (compact) 0.34f else 0.22f), p)
        } else {
            tp.typeface = style.font.typeface()
            tp.textSize = r * (if (compact) 0.38f else 0.24f)
            canvas.drawText(text, cx, cy + r * (if (compact) 0.12f else 0.07f), tp)
        }

        // unità
        tp.typeface = Typeface.DEFAULT
        tp.textSize = r * (if (compact) 0.14f else 0.10f)
        tp.alpha = 255
        canvas.drawText(spec.unit, cx, cy + r * (if (compact) 0.32f else 0.23f), tp)

        // etichetta
        if (spec.showLabel && !compact) {
            tp.textSize = r * 0.085f
            tp.alpha = 170
            canvas.drawText(spec.label, cx, cy - r * 0.24f, tp)
        }

        // min / max
        if (spec.showMinMax && lo != null && hi != null && !compact) {
            tp.textSize = r * 0.075f
            tp.alpha = 200
            val s = "min " + format(lo, spec) + "  max " + format(hi, spec)
            canvas.drawText(s, cx, if (style.minMaxBelow) cy + r * 0.80f else cy + r * 0.37f, tp)
        }
    }

    // ---------------------------------------------------------------- riquadro (barre, digitale, grafico)

    /** Disegna la cornice del riquadro e ritorna l'area interna. */
    private fun drawTile(canvas: Canvas, w: Float, h: Float, style: RenderStyle): RectF {
        val size = min(w, h)
        val m = size * 0.03f
        val outer = RectF(m, m, w - m, h - m)
        val ring = style.theme.ring.toInt()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            outer.left, outer.top, outer.right, outer.bottom,
            intArrayOf(
                ColorUtils.blendARGB(ring, 0xFFFFFFFF.toInt(), 0.6f),
                ColorUtils.blendARGB(ring, 0xFF000000.toInt(), 0.5f),
                ColorUtils.blendARGB(ring, 0xFFFFFFFF.toInt(), 0.5f),
                ColorUtils.blendARGB(ring, 0xFF000000.toInt(), 0.6f),
            ),
            null, Shader.TileMode.CLAMP,
        )
        canvas.drawRoundRect(outer, size * 0.09f, size * 0.09f, p)
        val inner = RectF(
            outer.left + size * 0.025f, outer.top + size * 0.025f,
            outer.right - size * 0.025f, outer.bottom - size * 0.025f,
        )
        p.shader = LinearGradient(
            inner.left, inner.top, inner.left, inner.bottom,
            style.theme.bg.toInt(), 0xFF000000.toInt(), Shader.TileMode.CLAMP,
        )
        canvas.drawRoundRect(inner, size * 0.07f, size * 0.07f, p)
        return inner
    }

    private fun drawBar(
        canvas: Canvas, w: Float, h: Float, spec: GaugeSpec,
        value: Double?, hi: Double?, style: RenderStyle,
    ) {
        val size = min(w, h)
        val ir = drawTile(canvas, w, h, style)
        val theme = style.theme
        val accent = withAlpha(accentFor(spec, value, style), style.opacity)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = theme.text.toInt()
        val pad = size * 0.07f

        if (spec.showLabel) {
            tp.textAlign = Paint.Align.LEFT
            tp.textSize = size * 0.09f
            tp.alpha = 170
            canvas.drawText(spec.label, ir.left + pad, ir.top + pad + tp.textSize, tp)
        }
        tp.alpha = 255
        tp.textAlign = Paint.Align.RIGHT
        tp.typeface = style.font.typeface()
        tp.textSize = size * 0.22f
        canvas.drawText(format(value, spec), ir.right - pad, ir.centerY() - size * 0.02f, tp)
        tp.typeface = Typeface.DEFAULT
        tp.textSize = size * 0.09f
        canvas.drawText(spec.unit, ir.right - pad, ir.centerY() + size * 0.08f, tp)

        val bl = ir.left + pad
        val br = ir.right - pad
        val bt = ir.bottom - pad - size * 0.22f
        val bb = bt + size * 0.10f
        val range = spec.max - spec.min
        fun fx(v: Double): Float = bl + (br - bl) * ((v - spec.min) / range).coerceIn(0.0, 1.0).toFloat()
        p.style = Paint.Style.FILL
        p.color = withAlpha(theme.ring.toInt(), 0.3f)
        canvas.drawRoundRect(RectF(bl, bt, br, bb), size * 0.03f, size * 0.03f, p)
        if (value != null) {
            p.color = accent
            canvas.drawRoundRect(RectF(bl, bt, max(bl + size * 0.02f, fx(value)), bb), size * 0.03f, size * 0.03f, p)
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = size * 0.012f
        spec.red?.let { v -> if (fx(v) < br) { p.color = WARN_COLOR.toInt(); canvas.drawLine(fx(v), bt - size * 0.02f, fx(v), bb + size * 0.02f, p) } }
        spec.low?.let { v -> if (fx(v) > bl) { p.color = WARN_COLOR.toInt(); canvas.drawLine(fx(v), bt - size * 0.02f, fx(v), bb + size * 0.02f, p) } }
        spec.yellow?.let { v -> p.color = YELLOW_COLOR.toInt(); canvas.drawLine(fx(v), bt - size * 0.02f, fx(v), bb + size * 0.02f, p) }
        if (spec.showPeak && hi != null) {
            p.color = 0xFFFFFFFF.toInt()
            canvas.drawLine(fx(hi), bt - size * 0.03f, fx(hi), bb + size * 0.03f, p)
        }
        if (spec.showScale) {
            tp.textSize = size * 0.075f
            tp.alpha = 200
            tp.textAlign = Paint.Align.LEFT
            canvas.drawText(format(spec.min, spec), bl, bb + size * 0.09f, tp)
            tp.textAlign = Paint.Align.RIGHT
            canvas.drawText(format(spec.max, spec), br, bb + size * 0.09f, tp)
        }
    }

    private fun drawDigital(
        canvas: Canvas, w: Float, h: Float, spec: GaugeSpec,
        value: Double?, lo: Double?, hi: Double?, style: RenderStyle,
    ) {
        val compact = style.compact
        val size = min(w, h)
        val ir = drawTile(canvas, w, h, style)
        val theme = style.theme
        val accent = withAlpha(accentFor(spec, value, style), 1f)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.textAlign = Paint.Align.CENTER
        tp.color = theme.text.toInt()
        val cx = ir.centerX()
        if (spec.showLabel) {
            tp.textSize = size * 0.10f
            tp.alpha = 170
            canvas.drawText(spec.label, cx, ir.top + size * 0.16f, tp)
        }
        val text = format(value, spec)
        if (style.font == GaugeFont.SETTE_SEG) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.style = Paint.Style.FILL
            p.color = accent
            drawSeven(canvas, text, cx, ir.centerY() + size * 0.02f, size * 0.30f, p)
        } else {
            tp.alpha = 255
            tp.color = accent
            tp.typeface = style.font.typeface()
            tp.textSize = size * 0.30f
            canvas.drawText(text, cx, ir.centerY() + size * 0.11f, tp)
        }
        tp.color = theme.text.toInt()
        tp.typeface = Typeface.DEFAULT
        tp.alpha = 255
        tp.textSize = size * 0.11f
        canvas.drawText(spec.unit, cx, ir.centerY() + size * 0.27f, tp)
        if (spec.showMinMax && lo != null && hi != null && !compact) {
            tp.textSize = size * 0.07f
            tp.alpha = 200
            canvas.drawText("min " + format(lo, spec) + "  max " + format(hi, spec), cx, ir.bottom - size * 0.05f, tp)
        }
    }

    private fun drawGraph(
        canvas: Canvas, w: Float, h: Float, spec: GaugeSpec,
        value: Double?, hist: List<Double>?, style: RenderStyle,
    ) {
        val size = min(w, h)
        val ir = drawTile(canvas, w, h, style)
        val theme = style.theme
        val accent = withAlpha(accentFor(spec, value, style), style.opacity)
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = theme.text.toInt()
        val pad = size * 0.06f
        if (spec.showLabel) {
            tp.textAlign = Paint.Align.LEFT
            tp.textSize = size * 0.09f
            tp.alpha = 170
            canvas.drawText(spec.label, ir.left + pad, ir.top + pad + tp.textSize, tp)
        }
        tp.alpha = 255
        tp.textAlign = Paint.Align.RIGHT
        tp.typeface = style.font.typeface()
        tp.textSize = size * 0.13f
        canvas.drawText(format(value, spec) + " " + spec.unit, ir.right - pad, ir.top + pad + tp.textSize, tp)

        val pl = ir.left + pad
        val pr = ir.right - pad
        val pt = ir.top + pad + size * 0.20f
        val pb = ir.bottom - pad
        val range = spec.max - spec.min
        fun fy(v: Double): Float = pb - (pb - pt) * ((v - spec.min) / range).coerceIn(0.0, 1.0).toFloat()

        // griglia e soglie
        p.style = Paint.Style.STROKE
        p.strokeWidth = size * 0.006f
        p.color = withAlpha(theme.ring.toInt(), 0.35f)
        for (i in 0..4) {
            val y = pt + (pb - pt) * i / 4f
            canvas.drawLine(pl, y, pr, y, p)
        }
        p.strokeWidth = size * 0.01f
        spec.red?.let { v -> if (v < spec.max) { p.color = WARN_COLOR.toInt(); canvas.drawLine(pl, fy(v), pr, fy(v), p) } }
        spec.low?.let { v -> if (v > spec.min) { p.color = WARN_COLOR.toInt(); canvas.drawLine(pl, fy(v), pr, fy(v), p) } }
        spec.yellow?.let { v -> p.color = YELLOW_COLOR.toInt(); canvas.drawLine(pl, fy(v), pr, fy(v), p) }

        // linea dei valori
        if (hist != null && hist.size >= 2) {
            val dx = (pr - pl) / 119f
            val line = Path()
            hist.forEachIndexed { i, v ->
                val x = pr - (hist.size - 1 - i) * dx
                if (i == 0) line.moveTo(x, fy(v)) else line.lineTo(x, fy(v))
            }
            val fill = Path(line)
            fill.lineTo(pr, pb)
            fill.lineTo(pr - (hist.size - 1) * dx, pb)
            fill.close()
            p.style = Paint.Style.FILL
            p.color = withAlpha(accent, 0.25f)
            canvas.drawPath(fill, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = size * 0.016f
            p.color = accent
            canvas.drawPath(line, p)
        }

        if (spec.showScale) {
            tp.typeface = Typeface.DEFAULT
            tp.textSize = size * 0.06f
            tp.alpha = 200
            tp.textAlign = Paint.Align.LEFT
            canvas.drawText(format(spec.max, spec), pl + size * 0.01f, pt + tp.textSize, tp)
            canvas.drawText(format(spec.min, spec), pl + size * 0.01f, pb - size * 0.01f, tp)
        }
    }

    // ---------------------------------------------------------------- cifre a 7 segmenti

    private val SEG = mapOf(
        '0' to "abcdef", '1' to "bc", '2' to "abdeg", '3' to "abcdg", '4' to "bcfg",
        '5' to "acdfg", '6' to "acdefg", '7' to "abc", '8' to "abcdefg", '9' to "abcdfg", '-' to "g",
    )

    /** Cifre a 7 segmenti disegnate da codice. h = altezza delle cifre. */
    private fun drawSeven(c: Canvas, text: String, cx: Float, cy: Float, h: Float, p: Paint) {
        val dw = h * 0.55f
        val gap = h * 0.18f
        val t = h * 0.11f
        var total = 0f
        for (ch in text) total += if (ch == '.' || ch == ',') t * 1.6f else dw + gap
        total -= gap
        var x = cx - total / 2f
        val top = cy - h / 2f
        val mid = cy
        val bot = cy + h / 2f
        for (ch in text) {
            if (ch == '.' || ch == ',') {
                c.drawCircle(x + t * 0.5f, bot - t * 0.5f, t * 0.6f, p)
                x += t * 1.6f
                continue
            }
            val segs = SEG[ch] ?: ""
            val x0 = x
            fun hseg(y: Float) {
                c.drawRoundRect(RectF(x0 + t * 0.6f, y - t / 2f, x0 + dw - t * 0.6f, y + t / 2f), t / 2f, t / 2f, p)
            }
            fun vseg(xx: Float, y0: Float, y1: Float) {
                c.drawRoundRect(RectF(xx - t / 2f, y0 + t * 0.6f, xx + t / 2f, y1 - t * 0.6f), t / 2f, t / 2f, p)
            }
            if ('a' in segs) hseg(top + t / 2f)
            if ('g' in segs) hseg(mid)
            if ('d' in segs) hseg(bot - t / 2f)
            if ('f' in segs) vseg(x0 + t / 2f, top, mid)
            if ('b' in segs) vseg(x0 + dw - t / 2f, top, mid)
            if ('e' in segs) vseg(x0 + t / 2f, mid, bot)
            if ('c' in segs) vseg(x0 + dw - t / 2f, mid, bot)
            x += dw + gap
        }
    }
}

@Composable
fun GaugeCompose(
    spec: GaugeSpec, raw: Double?, stat: Pair<Double, Double>?, hist: List<Double>?, style: RenderStyle,
    modifier: Modifier = Modifier.fillMaxSize(),
) {
    ComposeCanvas(modifier) {
        drawIntoCanvas { c ->
            GaugeRenderer.draw(
                c.nativeCanvas, size.width, size.height, spec,
                raw?.let { spec.convert(it) },
                stat?.let { spec.convert(it.first) },
                stat?.let { spec.convert(it.second) },
                hist?.map { spec.convert(it) },
                style,
            )
        }
    }
}
