package com.deef.control.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.compose.foundation.Canvas as ComposeCanvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import com.deef.control.obd.Pid
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Temi originali (nomi e grafica non legati a marchi di terzi). Colori in ARGB. */
enum class GaugeTheme(val label: String, val bg: Long, val ring: Long, val arc: Long, val text: Long) {
    COCKPIT("Cockpit", 0xFF0B0B0B, 0xFFCFCFCF, 0xFFE0201C, 0xFFF2F2F2),
    RACING("Racing", 0xFF101418, 0xFF8A94A0, 0xFFFFB000, 0xFFFFFFFF),
    ICE("Ice", 0xFF08121C, 0xFF7FB8E0, 0xFF2EC4FF, 0xFFEAF6FF),
}

const val WARN_COLOR = 0xFFFF3B30

/** Un solo disegno usato sia sul telefono (Compose) sia come immagine per Android Auto. */
object GaugeRenderer {

    fun format(v: Double?, pid: Pid): String = when {
        v == null -> "--"
        abs(v) < 100 -> String.format("%.1f", v)
        else -> String.format("%.0f", v)
    }

    fun draw(canvas: Canvas, w: Float, h: Float, pid: Pid, value: Double?, theme: GaugeTheme) {
        val size = min(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val r = size / 2f * 0.96f
        val span = 270f
        val start = 135f

        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        // sfondo
        p.style = Paint.Style.FILL
        p.color = theme.bg.toInt()
        canvas.drawCircle(cx, cy, r, p)

        // anello esterno sottile
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.015f
        p.color = theme.ring.toInt()
        canvas.drawCircle(cx, cy, r * 0.98f, p)

        // traccia dell'arco
        val arcR = r * 0.74f
        val rect = RectF(cx - arcR, cy - arcR, cx + arcR, cy + arcR)
        p.strokeWidth = r * 0.09f
        p.strokeCap = Paint.Cap.BUTT
        p.color = (theme.ring and 0x00FFFFFF or 0x40000000).toInt()
        canvas.drawArc(rect, start, span, false, p)

        // arco del valore
        val range = (pid.max - pid.min).takeIf { it > 0 } ?: 1.0
        val frac = if (value == null) 0f else ((value - pid.min) / range).coerceIn(0.0, 1.0).toFloat()
        val warn = value != null && value >= pid.warn
        p.color = (if (warn) WARN_COLOR else theme.arc).toInt()
        canvas.drawArc(rect, start, span * frac, false, p)

        // tacche e numeri della scala
        val tp = Paint(Paint.ANTI_ALIAS_FLAG)
        tp.color = theme.text.toInt()
        tp.textAlign = Paint.Align.CENTER
        tp.textSize = r * 0.10f
        val steps = 6
        for (n in 0..steps) {
            val a = Math.toRadians((start + span * n / steps).toDouble())
            val lr = r * 0.90f
            val tx = cx + (lr * cos(a)).toFloat()
            val ty = cy + (lr * sin(a)).toFloat() + tp.textSize / 3f
            val v = pid.min + range * n / steps
            val label = if (range > 20) String.format("%.0f", v) else String.format("%.1f", v)
            canvas.drawText(label, tx, ty, tp)
        }

        // cerchio centrale
        p.style = Paint.Style.FILL
        p.color = 0xFF151515.toInt()
        canvas.drawCircle(cx, cy, r * 0.55f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.012f
        p.color = theme.ring.toInt()
        canvas.drawCircle(cx, cy, r * 0.55f, p)

        // valore, unita, nome
        tp.typeface = Typeface.DEFAULT_BOLD
        tp.textSize = r * 0.30f
        canvas.drawText(format(value, pid), cx, cy + r * 0.06f, tp)
        tp.typeface = Typeface.DEFAULT
        tp.textSize = r * 0.13f
        canvas.drawText(pid.unit, cx, cy + r * 0.24f, tp)
        tp.textSize = r * 0.11f
        tp.alpha = 170
        canvas.drawText(pid.shortName, cx, cy - r * 0.28f, tp)
    }
}

@Composable
fun GaugeCompose(pid: Pid, value: Double?, theme: GaugeTheme, modifier: Modifier = Modifier.fillMaxSize()) {
    ComposeCanvas(modifier) {
        drawIntoCanvas { c -> GaugeRenderer.draw(c.nativeCanvas, size.width, size.height, pid, value, theme) }
    }
}
